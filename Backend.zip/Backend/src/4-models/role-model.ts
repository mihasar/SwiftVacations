enum RoleModel {
    Admin = "Admin",
    User = "User"
}

export default RoleModel;